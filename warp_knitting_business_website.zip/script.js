function toggleMenu(){document.getElementById("navLinks").classList.toggle("open");}
function sendMessage(e){
  e.preventDefault();
  const name=document.getElementById("name").value;
  document.getElementById("formMessage").textContent=`Thanks ${name}! Your enquiry is ready. Connect this form to your email/WhatsApp before publishing.`;
}
document.querySelectorAll("#navLinks a").forEach(a=>a.addEventListener("click",()=>document.getElementById("navLinks").classList.remove("open")));
